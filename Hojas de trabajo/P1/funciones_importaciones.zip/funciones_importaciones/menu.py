import funciones as func;


opcion = 0
while opcion != 7 :
    
    print("\n\n\n\n");
    print("1. Pasar dolares a pesos\n");
    print("2. Pasar euros a pesos\n");
    print("3. Pasar pesos a dolares\n");
    print("4. Pasar pesos a euros\n");
    print("5. Pasar euros a dolares\n");
    print("6. Pasar dolares a euros\n");
    print("7. Salir\n");
    
    opcion = int( input( "Por favor seleccione una opcion: " ) );
    
    if opcion == 1:
        dolares = float(  input( "Por favor ingrese los dolares: " ) )
        pesos = func.convertir_dolares_pesos( dolares )
        print( "La cantidad de pesos es: " + str(pesos)  );
        
    if opcion == 2:
        euros = float(  input( "Por favor ingrese los euros: " ) )
        pesos = func.convertir_euros_pesos( euros )
        print( "La cantidad de dólares es: " + str(pesos)  );
        
    if opcion == 3:
        dolares = 0
    
    if opcion == 4:
        dolares = 0
        
    if opcion == 5:
        dolares = 0
        
    if opcion == 6:
        dolares = 0
