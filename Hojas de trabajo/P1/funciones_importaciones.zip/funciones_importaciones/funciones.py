#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 18 04:24:42 2023

@author: mac
"""

def convertir_dolares_pesos(dolares: float)-> float:
    pesos = dolares * 4100;
    return pesos;


def convertir_euros_pesos(euros: float)-> float:
    pesos = euros * 4453;
    return pesos;

def convertir_pesos_dolares(pesos: float)-> float:
   return 0;   


def convertir_pesos_euros(euros: float)-> float:
   return 0;

def convertir_dolares_euros(dolares: float)-> float:
   return 0;

def convertir_euros_dolares(euros: float)-> float:
   return 0;